@extends('mail.layout')
@section('content')
<span>Hi {{$data['name']}}!&#128075;</span>
We are happy to have you on board Your OnePilatesStudio account has been created You can now log in to our OnePilatesStudio APP store.	
@endsection