
<?php $__env->startSection('content'); ?>
<span>Hi <?php echo e($data['name']); ?>!&#128075;</span>
We are happy to have you on board Your OnePilatesStudio account has been created You can now log in to our OnePilatesStudio APP store.	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mail.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pilates-bouncer\resources\views/mail/templates/welcome_mail.blade.php ENDPATH**/ ?>